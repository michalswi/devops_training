#!/bin/bash

echo "###############"
echo "TEST SCRIPT"
echo "###############"

vmstat
